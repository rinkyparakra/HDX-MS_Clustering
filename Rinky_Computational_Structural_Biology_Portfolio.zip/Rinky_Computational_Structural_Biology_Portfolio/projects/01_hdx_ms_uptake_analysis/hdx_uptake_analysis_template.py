import pandas as pd
import numpy as np

INPUT = "example_hdx_input.csv"
OUTPUT = "example_hdx_output_generated.csv"

def classify_delta(delta, threshold=0.15):
    if delta <= -threshold:
        return "Protection"
    if delta >= threshold:
        return "Deprotection"
    return "No major change"

def main():
    df = pd.read_csv(INPUT)

    summary = (
        df.groupby(["peptide", "start", "end", "time_min", "state"])["uptake_da"]
        .agg(["mean", "std", "count"])
        .reset_index()
    )

    pivot = summary.pivot_table(
        index=["peptide", "start", "end", "time_min"],
        columns="state",
        values="mean"
    ).reset_index()

    pivot.columns.name = None
    pivot = pivot.rename(columns={"Apo": "apo_mean", "Bound": "bound_mean"})

    pivot["delta_bound_minus_apo"] = pivot["bound_mean"] - pivot["apo_mean"]
    pivot["interpretation"] = pivot["delta_bound_minus_apo"].apply(classify_delta)

    pivot.to_csv(OUTPUT, index=False)
    print(f"Saved: {OUTPUT}")

if __name__ == "__main__":
    main()
